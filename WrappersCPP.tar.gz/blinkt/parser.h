// Include guard ----------------------------------------------------------------

#ifndef PARSER_H
#define PARSER_H

#include "clinkt.h"

std::string cleanHexCode(std::string hexValue);

#endif // PARSER_H
